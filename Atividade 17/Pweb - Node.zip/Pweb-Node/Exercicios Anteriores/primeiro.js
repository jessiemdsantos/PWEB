console.log("primeiro exemplo");



